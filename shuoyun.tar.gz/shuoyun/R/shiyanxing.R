#' Using a dataframe specific column to plot a cloud figure.Grab a specific website distinguished as the ability that help us enjoy a number of fantasy novels to obtain the infrequent data collation of the name of books to draw a word cloud for them to have a better understanding of both which words that most authors shows a strong preference and the frequency of different author's appearance.
#'
#' @return a figure as wordcloud2 object,You can see a lexical analysis of the popular novels
#' @export
#'
#' @examples
#' xsy()
xsy<-function(a){
  library(readxl)
  library(jiebaRD)
  library(jiebaR)
  library(rvest)
  library(xml2)
  library(wordcloud2)
  Link0<-"https://www.xbiquge.la/xiaoshuodaquan/"
  DLink<-read_html(Link0)
  ppp<-DLink%>%html_nodes('div.novellist li a')%>%html_text()
  fenci1<-worker()
  cihui<-segment(ppp,fenci1)
  ccc<-table(cihui)
  ccc<-sqrt(ccc)
  ccc<-ccc[ccc>3]
  wordcloud2(ccc,size=0.5,
             color = "random-light",
             backgroundColor="silver",
             shape="star")

}
